#' Find Box Breaks
#'
#' @param v vector with observations
#' @param hinge multuplier for interquartile range (default 1.5)
#'
#' @return bb (boxbreaks): A vector with 7 break points
#'
#' @examples boxbreaks(get.var("spindles", 1840massspindles), hinge = 1.5)

boxbreaks <- function(v,hinge=1.5) {
  qv <- unname(quantile(v))
  iqr <- qv[4] - qv[2]
  upfence <- qv[4] + hinge * iqr
  lofence <- qv[2] - hinge * iqr
  bb <- vector(mode="numeric",length=7)
  if (lofence < qv[1]) {
    bb[1] <- lofence
    bb[2] <- floor(qv[1])
  } else {
    bb[2] <- lofence
    bb[1] <- qv[1]
  }
  if (upfence > qv[5]) {
    bb[7] <- upfence
    bb[6] <- ceiling(qv[5])
  } else {
    bb[6] <- upfence

    bb[7] <- qv[5]
  }
  bb[3:5] <- qv[2:4]
  return(bb)}
