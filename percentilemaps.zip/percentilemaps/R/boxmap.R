#' Box Map
#'
#' box map according to given variable using tmap
#'
#' @param vnam variable name (as character, in quotes)
#' @param df of sf data frame
#' @param legtitle the title of the legend (default: vnam)
#' @param mtitle the title of the map (default: box map)
#' @param hinge the multiplier for determining outliers with iqr
#' @param mpalette the color scheme of the map, default "-RdBu"
#'
#'
#'
#' @examples boxmap("spindles",1840massspindles,legtitle="Spindles",mtitle="Spindles in 1840",hinge=1.5,mpalette="-RdBu")
boxmaps <- function(vnam,df,legtitle=NA,mtitle="Box Map",hinge=1.5, mpalette = "-RdBu"){
  var <- get.var(vnam,df)
  bb <- boxbreaks(var)
  tm_shape(df) +
    tm_fill(vnam,title=legtitle,breaks=bb,palette=mpalette,
            labels = c("lower outlier", "< 25%", "25% - 50%", "50% - 75%","> 75%", "upper outlier"))  +
    tm_borders() +
    tm_layout(title = mtitle, title.position = c("right","bottom"))
}
