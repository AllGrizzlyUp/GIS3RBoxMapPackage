#' Get Variable
#'
#' @param vname variable name (as character, in quotes)
#' @param df name of sf data frame
#'
#' @return V a vector with values without column name
#'
#' @examples get.var("spindles", 1840massspindles
get.var <- function(vname,df){
V <-df[vname] %>% st_set_geometry(NULL)
V <- unname(V[,1])
return(V)
}
