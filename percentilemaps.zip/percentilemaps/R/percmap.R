#'percmap
#'
#'Create Percentile Map with chosen variable using tmap
#'
#' @param vnam the name of the variable being analyzed
#' @param df the dataset from which the variable is drawn
#' @param legtitle the title of the legend (default: vnam)
#' @param mtitle the title of the map (default: Percentile Map)
#' @param hinge the multiplier for determining outliers with iqr
#' @param mpalette the color scheme of the map, default "-RdBu"
#'
#'
#' @examples percmap("spindles",1840massspindles,legtitle="Spindles",mtitle="Spindles in 1840",hinge=1.5,mpalette="-RdBu")
percmap <- function(vnam,df,legtitle=NA,mtitle="Percentile Map", mpalette = "-RdBu"){
  percent <- c(0,.01,.1,.5,.9,.99,1)

  var <- get.var(vnam,df)
  bperc <- quantile(var,percent)
  tm_shape(df) +
    tm_fill(vnam,title=legtitle,breaks=bperc,palette = mpalette,
            labels=c("< 1%", "1% - %10", "10% - 50%", "50% - 90%","90% - 99%", "> 99%"))  +
    tm_borders() +
    tm_layout(title = mtitle, title.position = c("right","bottom"))
}
